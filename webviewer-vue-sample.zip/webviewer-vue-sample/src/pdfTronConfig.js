// eslint-disable-next-line no-unused-labels
path: "`{process.env.BASE_URL}lib`";
